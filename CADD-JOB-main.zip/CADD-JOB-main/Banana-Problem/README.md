## Problem Statment :-

Design hardware to add two 8-bit unsigned BCD numbers. Sketch a schematic for your design, and
write an HDL module for the BCD adder. The inputs are A, B, and Cin, and the outputs are S and
Cout. Cin and Cout are 1-bit carries, and A, B, and S are 8-bit BCD numbers.

### Instructions :- 

- Understand BCD numbers and the addition of BCD numbers
- Write the algorithm for BCD addition
- Functional simulation
- Synthesis

